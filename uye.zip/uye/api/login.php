<?php
require_once '../config.php';

$method = $_SERVER['REQUEST_METHOD'];

if ($method !== 'POST' && $method !== 'GET') {
    sendResponse(false, 'Invalid request method');
    exit;
}

$data = [];

if ($method === 'POST') {
    $rawInput = file_get_contents("php://input");
    
    // Check if it's already an array (for form-data/$_POST)
    if (isset($_POST['username'])) {
        $data = $_POST;
    } else {
        $data = json_decode($rawInput, true);
    }

    // Fallback: accept form-encoded input if JSON parse fails
    if (!$data || !is_array($data)) {
        $parsed = [];
        parse_str($rawInput, $parsed);
        if (!empty($parsed)) {
            $data = $parsed;
        } elseif (!empty($_REQUEST)) {
            $data = $_REQUEST;
        }
    }
} else { // GET request
    $data = $_GET;
}

if (!isset($data['username']) || !isset($data['password'])) {
    sendResponse(false, 'Username and password are required');
    exit;
}

$username = $data['username'];
$password = $data['password'];

global $conn;

try {
    // Get admin_username from settings
    $sql_user = "SELECT setting_value FROM settings WHERE setting_key = 'admin_username'";
    $result_user = $conn->query($sql_user);
    if (!$result_user || $result_user->num_rows === 0) {
        throw new Exception('Admin username not found in settings.');
    }
    $stored_username = json_decode($result_user->fetch_assoc()['setting_value'], true);
    if (is_array($stored_username)) {
        $stored_username = reset($stored_username);
    }
    $stored_username = is_string($stored_username) ? trim($stored_username) : '';

    // Get admin_password from settings
    $sql_pass = "SELECT setting_value FROM settings WHERE setting_key = 'admin_password'";
    $result_pass = $conn->query($sql_pass);
    if (!$result_pass || $result_pass->num_rows === 0) {
        throw new Exception('Admin password not found in settings.');
    }
    $stored_password_value = json_decode($result_pass->fetch_assoc()['setting_value'], true);
    if (is_array($stored_password_value)) {
        $stored_password_value = reset($stored_password_value);
    }
    if (is_string($stored_password_value)) {
        $stored_password_value = trim($stored_password_value);
    }

    logError('login attempt: user="' . $username . '" (len=' . strlen($username) . '), stored="' . $stored_username . '" (len=' . strlen($stored_username) . ')');
    logError('password attempt: pass="' . $password . '" (len=' . strlen($password) . '), stored="' . (is_string($stored_password_value) ? $stored_password_value : 'NOT_STRING') . '" (len=' . (is_string($stored_password_value) ? strlen($stored_password_value) : 0) . ')');

    // Verify username first
    $trimmedUser = trim((string)$username);
    $trimmedStoredUser = trim((string)$stored_username);
    logError('DEBUG: Comparing user "' . $trimmedUser . '" with stored "' . $trimmedStoredUser . '"');
    
    if ($trimmedUser !== $trimmedStoredUser) {
        logError('Username mismatch: "' . $trimmedUser . '" !== "' . $trimmedStoredUser . '"');
        sendResponse(false, 'Invalid username or password');
    }

    $passwordInfo = password_get_info((string)$stored_password_value);
    logError('DEBUG: Password algo (raw): ' . $passwordInfo['algo']);
    
    // Check if it's already a valid bcrypt hash
    $isBcrypt = (substr((string)$stored_password_value, 0, 4) === '$2y$');
    logError('DEBUG: Is Bcrypt? ' . ($isBcrypt ? 'YES' : 'NO'));

    // If password was stored in plain text, migrate to hash after validating
    if (!$isBcrypt) {
        logError('Checking plain text password');
        $inputPass = trim((string)$password);
        $storedPass = trim((string)$stored_password_value);
        logError('DEBUG: Comparing pass "' . $inputPass . '" with stored "' . $storedPass . '"');
        
        if ($inputPass === $storedPass) {
            logError('Plain text password match, migrating...');
            $newHash = password_hash($inputPass, PASSWORD_DEFAULT);
            $escaped = $conn->real_escape_string(json_encode($newHash, JSON_UNESCAPED_UNICODE));
            $updateSql = "UPDATE settings SET setting_value = '$escaped' WHERE setting_key = 'admin_password'";
            if (!$conn->query($updateSql)) {
                throw new Exception('Password migration failed: ' . $conn->error);
            }
            sendResponse(true, 'Login successful (migrated)');
        } else {
            logError('Plain text password mismatch');
            sendResponse(false, 'Invalid username or password');
        }
    }

    // Hashed password verification
    if ($isBcrypt && password_verify(trim((string)$password), (string)$stored_password_value)) {
        sendResponse(true, 'Login successful (hash)');
    }

    sendResponse(false, 'Invalid username or password');

} catch (Exception $e) {
    logError($e->getMessage());
    sendResponse(false, 'An error occurred during login: ' . $e->getMessage());
}
?>
