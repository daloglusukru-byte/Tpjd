<?php
// Database Setup Script
$servername = "localhost";
$username = "root";
$password = "123456";
$dbname = "tpjd";

// Create connection (without database first)
$conn = new mysqli($servername, $username, $password);

// Check connection
if ($conn->connect_error) {
    die("Bağlantı hatası: " . $conn->connect_error);
}

// Create database
$sql = "CREATE DATABASE IF NOT EXISTS $dbname";
if ($conn->query($sql) === TRUE) {
    echo "✅ Veritabanı başarıyla oluşturuldu.<br>";
} else {
    echo "❌ Veritabanı oluşturma hatası: " . $conn->error . "<br>";
}

// Select database
$conn->select_db($dbname);

// Create tables
$tables = [
    // Members table
    "CREATE TABLE IF NOT EXISTS members (
        id VARCHAR(50) PRIMARY KEY,
        memberNo VARCHAR(20) UNIQUE NOT NULL,
        firstName VARCHAR(100) NOT NULL,
        lastName VARCHAR(100) NOT NULL,
        tcNo VARCHAR(11) UNIQUE NOT NULL,
        gender VARCHAR(20),
        birthDate DATE,
        bloodType VARCHAR(10),
        email VARCHAR(100) UNIQUE NOT NULL,
        phone VARCHAR(20) NOT NULL,
        phoneHome VARCHAR(20),
        maritalStatus VARCHAR(20),
        city VARCHAR(50),
        district VARCHAR(50),
        neighborhood VARCHAR(50),
        address TEXT,
        fatherName VARCHAR(100),
        motherName VARCHAR(100),
        graduation VARCHAR(200),
        graduationYear INT,
        employmentStatus VARCHAR(50),
        workplace VARCHAR(200),
        position VARCHAR(100),
        birthCity VARCHAR(50),
        birthDistrict VARCHAR(50),
        volumeNo VARCHAR(50),
        familyNo VARCHAR(50),
        lineNo VARCHAR(50),
        notes TEXT,
        membershipType VARCHAR(50) NOT NULL,
        aidatAktif BOOLEAN DEFAULT TRUE,
        membershipStatus VARCHAR(20) DEFAULT 'aktif',
        exitDate DATE,
        exitReasonType VARCHAR(100),
        exitReason TEXT,
        createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
        updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_memberNo (memberNo),
        INDEX idx_email (email),
        INDEX idx_tcNo (tcNo),
        INDEX idx_membershipStatus (membershipStatus),
        INDEX idx_aidatAktif (aidatAktif)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
    
    // Payments table
    "CREATE TABLE IF NOT EXISTS payments (
        id VARCHAR(50) PRIMARY KEY,
        memberId VARCHAR(50) NOT NULL,
        amount DECIMAL(10, 2) NOT NULL,
        type VARCHAR(50) NOT NULL,
        year INT NOT NULL,
        date DATE NOT NULL,
        receiptNo VARCHAR(50),
        description TEXT,
        status VARCHAR(20) NOT NULL,
        createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
        updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (memberId) REFERENCES members(id) ON DELETE CASCADE,
        INDEX idx_memberId (memberId),
        INDEX idx_year (year),
        INDEX idx_type (type),
        INDEX idx_status (status),
        INDEX idx_date (date)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
    
    // Notifications table
    "CREATE TABLE IF NOT EXISTS notifications (
        id VARCHAR(50) PRIMARY KEY,
        title VARCHAR(200) NOT NULL,
        message TEXT NOT NULL,
        recipients JSON,
        priority VARCHAR(20) DEFAULT 'normal',
        sentAt DATETIME DEFAULT CURRENT_TIMESTAMP,
        createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_sentAt (sentAt)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
    
    // Settings table
    "CREATE TABLE IF NOT EXISTS settings (
        id INT PRIMARY KEY AUTO_INCREMENT,
        setting_key VARCHAR(100) UNIQUE NOT NULL,
        setting_value JSON,
        updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_key (setting_key)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
];

foreach ($tables as $sql) {
    if ($conn->query($sql) === TRUE) {
        echo "✅ Tablo başarıyla oluşturuldu.<br>";
    } else {
        echo "❌ Tablo oluşturma hatası: " . $conn->error . "<br>";
    }
}

// Insert default settings
$settings_sql = "INSERT INTO settings (setting_key, setting_value) VALUES 
('aidat_settings', '{\"Asil Üye\": 100, \"Asil Onursal\": 0, \"Öğrenci Üye\": 50, \"Fahri Üye\": 100, \"Fahri Onursal\": 0}'),
('admin_username', '\"admin\"'),
('admin_password', '\"admin123\"')
ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)";

if ($conn->query($settings_sql) === TRUE) {
    echo "✅ Varsayılan ayarlar başarıyla eklendi.<br>";
} else {
    echo "❌ Ayarlar eklenirken hata: " . $conn->error . "<br>";
}

$conn->close();
echo "<br><strong>✅ Veritabanı kurulumu tamamlandı!</strong>";
?>
