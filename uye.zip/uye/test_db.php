<?php
// Test database connection and tables
$servername = "localhost";
$username = "tpjdorgt_uyelik";
$password = "e05+y;g%P7H8L+2h";
$dbname = "tpjdorgt_uyelik";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Bağlantı hatası: " . $conn->connect_error);
}

echo "<h2>Veritabanı Test Sonuçları</h2>";

// Check tables
$tables = ['members', 'payments', 'notifications', 'settings'];
foreach ($tables as $table) {
    $result = $conn->query("SHOW TABLES LIKE '$table'");
    if ($result->num_rows > 0) {
        echo "✅ $table tablosu mevcut<br>";
    } else {
        echo "❌ $table tablosu bulunamadı<br>";
    }
}

// Check settings
echo "<h3>Ayarlar</h3>";
$result = $conn->query("SELECT * FROM settings");
if ($result) {
    while ($row = $result->fetch_assoc()) {
        echo "Anahtar: " . $row['setting_key'] . " = " . $row['setting_value'] . "<br>";
    }
}

$conn->close();
?>
