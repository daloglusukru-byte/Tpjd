<?php
// Initialize database and load sample data
require_once 'setup.php';

// After setup, load sample data
echo "<h2>Örnek Veriler Yükleniyor...</h2>";

$servername = "localhost";
$username = "root";
$password = "123456";
$dbname = "tpjd";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Bağlantı hatası: " . $conn->connect_error);
}

// Sample members
$members = [
    ['TPJD001', 'Ahmet', 'Yılmaz', '12345678901', 'ahmet@email.com', '+905551234567', 'Asil Üye'],
    ['TPJD002', 'Ayşe', 'Demir', '12345678902', 'ayse@email.com', '+905551234568', 'Öğrenci Üye'],
    ['TPJD003', 'Mehmet', 'Kaya', '12345678903', 'mehmet@email.com', '+905551234569', 'Fahri Üye'],
];

$insertedCount = 0;
foreach ($members as $member) {
    $id = 'member_' . time() . '_' . rand(1000, 9999);
    $memberNo = $conn->real_escape_string($member[0]);
    $firstName = $conn->real_escape_string($member[1]);
    $lastName = $conn->real_escape_string($member[2]);
    $tcNo = $conn->real_escape_string($member[3]);
    $email = $conn->real_escape_string($member[4]);
    $phone = $conn->real_escape_string($member[5]);
    $membershipType = $conn->real_escape_string($member[6]);
    
    $sql = "INSERT INTO members (id, memberNo, firstName, lastName, tcNo, email, phone, membershipType, city, address, aidatAktif)
            VALUES ('$id', '$memberNo', '$firstName', '$lastName', '$tcNo', '$email', '$phone', '$membershipType', 'İstanbul', 'Test Adresi', 1)";
    
    if ($conn->query($sql)) {
        $insertedCount++;
        echo "✅ $firstName $lastName eklendi<br>";
    } else {
        echo "❌ Hata: " . $conn->error . "<br>";
    }
}

echo "<br><strong>✅ Kurulum Tamamlandı!</strong><br>";
echo "Toplam $insertedCount üye eklendi.<br>";
echo "<a href='index.html'>Sisteme Giriş Yap</a>";

$conn->close();
?>
